<!-- body_message.blade.php-->
@php
    $color = $content['message_color'] ?? '#333333';
    $size = $content['message_size'] ?? '16px';
    $align = $content['message_align'] ?? 'left';
    $bold = !empty($content['bold']) ? 'bold' : 'normal';
    $italic = !empty($content['italic']) ? 'italic' : 'normal';
    $underline = !empty($content['underline']) ? 'underline' : 'none';
@endphp

<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin:4px 0;">
  <tr>
    <td align="{{ $align }}" style="
        color: {{ $color }};
        font-size: {{ $size }};
        font-weight: {{ $bold }};
        font-style: {{ $italic }};
        text-decoration: {{ $underline }};
        font-family: Arial, Helvetica, sans-serif;
        line-height: {{ is_numeric($size) ? $size * 1.3 . 'px' : '1.3' }};
        mso-line-height-rule: exactly;
        white-space: pre-line;
        padding: 2px 0; /* 🔑 controla el espacio interno */
    ">
        {!! $content['message'] ?? 'Mensaje' !!}
    </td>
  </tr>
</table>

