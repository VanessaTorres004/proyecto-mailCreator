@php
  $gridContent = $content['grid_content'] ?? [];
  $gridGap = intval($content['grid_gap'] ?? $content['grid_gap_backup'] ?? 10);
  $gridRowGap = intval($content['grid_row_gap'] ?? 8);
  $gridBorderRadius = intval($content['grid_border_radius'] ?? $content['grid_border_radius_backup'] ?? 0);
  $columns = intval($content['grid_columns'] ?? 2);
  $tableWidth = 600;
@endphp

@if(!empty($gridContent))
<style>
  .email-table {
    width: 100%;
    max-width: {{ $tableWidth }}px;
    margin: 15px auto;
    border-collapse: separate;
    border-spacing: 0;
    font-family: Arial, Helvetica, sans-serif;
  }

  .email-cell {
    background-color: #ffffff;
    border-radius: {{ $gridBorderRadius }}px;
    padding: 0;
    vertical-align: top;
    box-sizing: border-box;
  }

  .grid-text {
    line-height: 1.4;
    color: #333333;
    margin: 0;
    word-wrap: break-word;
    overflow-wrap: break-word;
    white-space: normal;
    font-size: 14px;
    margin:8px;
  }

  .grid-image {
    display: block;
    width: 100% !important;
    height: auto !important;
  }

  .gap-column { font-size:0; line-height:0; }
  .gap-row { height: {{ $gridRowGap }}px; font-size:0; line-height:0; }

  @media only screen and (max-width: 600px) {
    .stack-column, .stack-column td { display: block !important; width: 100% !important; margin-bottom: 10px; }
    .email-cell { padding: 0 !important; width: 100% !important; }
    .gap-column { display: none !important; width:0 !important; height:0 !important; }
    .gap-row { height: {{ intval($gridRowGap/2) }}px !important; }
    .grid-image { width: 100% !important; height: auto !important; }
  }

  @media only screen and (max-width: 480px) {
    .grid-text { font-size: 13px !important; }
  }
</style>

<!--[if mso]>
<table width="{{ $tableWidth }}" cellpadding="0" cellspacing="0" border="0" align="center">
<tr><td>
<![endif]-->

<table class="email-table" cellpadding="0" cellspacing="0" border="0" role="presentation">
  @php $chunks = array_chunk($gridContent, $columns); @endphp
  @foreach($chunks as $rowIndex => $row)

    {{-- Gap vertical entre filas, solo si $gridRowGap > 0 --}}
    @if($rowIndex > 0 && $gridRowGap > 0)
      <tr class="gap-row"><td colspan="{{ $columns*2-1 }}" class="gap-row">&nbsp;</td></tr>
    @endif

    <tr>
      @foreach($row as $index => $item)
        @php
          $types = $item['types'] ?? ['text'];
          $hasContent = (in_array('text', $types) && !empty(trim(strip_tags($item['text'] ?? ''))))
                        || (in_array('image', $types) && !empty($item['image']))
                        || (in_array('button', $types) && !empty(trim($item['button_text'] ?? '')) && trim($item['button_text'] ?? '') !== 'Click aquí');
          $backgroundColor = $item['background_color'] ?? '#ffffff';
          $fontSize = intval($item['font_size'] ?? 14);
          $fontSize = min($fontSize,16); 
          $colWidth = intval(($tableWidth - $gridGap*($columns-1))/$columns);
          $btn = [
            'text' => $item['button_text'] ?? '',
            'link' => $item['button_link'] ?? '#',
            'bg' => $item['button_bg_color'] ?? '#0d6efd',
            'color' => $item['button_text_color'] ?? '#fff',
            'size' => min($item['button_font_size'] ?? 16,16),
            'radius' => $item['button_border_radius'] ?? 4,
            'bold' => $item['button_bold'] ?? false,
            'italic' => $item['button_italic'] ?? false,
            'underline' => $item['button_underline'] ?? false
          ];
          $textDecoration = $btn['underline'] ? 'underline' : 'none';
          $fontWeight = $btn['bold'] ? 'bold' : 'normal';
          $fontStyle = $btn['italic'] ? 'italic' : 'normal';
        @endphp

        @if($hasContent)
<td class="email-cell stack-column" width="{{ $colWidth }}" 
    style="background-color: {{ $backgroundColor }}; border-radius: {{ $gridBorderRadius }}px; 
           padding: 0; vertical-align: top; font-size: {{ $fontSize }}px; 
           box-sizing: border-box; mso-table-lspace:0pt; mso-table-rspace:0pt;">

  {{-- Imagen arriba --}}
@if(in_array('image', $types) && !empty($item['image']))
  @php
    $imgBorder = $item['image_border_width'] ?? 0;
    $imgBorderColor = $item['image_border_color'] ?? '#000';
    $imgRadius = $item['image_border_radius'] ?? 0; 
    $imgWidth = $item['image_width'] ?? 200;
    $imgHeight = $item['image_height'] ?? '';
    $imgAlign = $item['image_align'] ?? 'center';
    $imgPadding = $item['image_padding'] ?? $gridGap; // 👈 usa el mismo gap
  @endphp
  <table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse: collapse; margin:0;">
    <tr>
      <td style="padding:{{ $imgPadding }}px; margin:0; text-align: {{ $imgAlign }};">
        <img src="{{ asset($item['image']) }}" alt="Imagen"
             width="{{ $imgWidth }}" 
             @if(!empty($imgHeight))
             height="{{ $imgHeight }}"
             @endif
             style="display:block; width:{{ $imgWidth }}px !important; 
                    @if(!empty($imgHeight))
                    height:{{ $imgHeight }}px !important;
                    @else
                    height:auto !important;
                    @endif
                    max-width:100%; border-radius: {{ $imgRadius }}px; 
                    border: {{ $imgBorder }}px solid {{ $imgBorderColor }};
                    @if($imgAlign === 'center')
                    margin: 0 auto;
                    @elseif($imgAlign === 'right')
                    margin: 0 0 0 auto;
                    @else
                    margin: 0 auto 0 0;
                    @endif">
      </td>
    </tr>
  </table>
@endif


  {{-- Texto debajo --}}
  @if(in_array('text', $types) && !empty(trim(strip_tags($item['text'] ?? ''))))
    <div class="grid-text" style="font-size: {{ $fontSize }}px; padding: 6px 8px 5px 8px;">
      {!! $item['text'] !!}
    </div>
  @endif

{{-- Botón debajo --}}
@if(!empty($btn['text']))
  <!--[if mso]>
  <center>
    <v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" 
                 xmlns:w="urn:schemas-microsoft-com:office:word"
                 href="{{ $btn['link'] }}" 
                 style="height:60spx;v-text-anchor:middle;width:220px;" 
                 arcsize="{{ $btn['radius'] }}%" 
                 strokecolor="none" 
                 fillcolor="{{ $btn['bg'] }}">
      <w:anchorlock/>
      <center style="color:{{ $btn['color'] }};font-family:Arial,sans-serif;
                     font-size:{{ $btn['size'] }}px;font-weight:{{ $fontWeight }};
                     font-style:{{ $fontStyle }};text-decoration:none;">
        {{ $btn['text'] }}
      </center>
    </v:roundrect>
  </center>
  <![endif]-->

  <!--[if !mso]><!-- -->
  <table role="presentation" border="0" cellspacing="0" cellpadding="0" align="center" style="margin:0 auto;">
    <tr>
      <td align="center" bgcolor="{{ $btn['bg'] }}" 
          style="border-radius:{{ $btn['radius'] }}px; background:{{ $btn['bg'] }}; text-align:center;">
        <a href="{{ $btn['link'] }}" target="_blank"
           style="display:block; padding:10px 20px; font-family:Arial,sans-serif;
                  font-size:{{ $btn['size'] }}px; font-weight:{{ $fontWeight }};
                  font-style:{{ $fontStyle }}; text-decoration:none;
                  color:{{ $btn['color'] }}; border-radius:{{ $btn['radius'] }}px;">
          {{ $btn['text'] }}
        </a>
      </td>
    </tr>
  </table>
  <!--<![endif]-->
@endif



</td>

          {{-- Gap horizontal solo si $gridGap > 0 --}}
          @if($index < count($row)-1 && $gridGap > 0)
            <td class="gap-column" style="width: {{ $gridGap }}px;">&nbsp;</td>
          @endif
        @endif
      @endforeach

      {{-- Relleno si faltan columnas --}}
      @php $remaining = $columns - count($row); @endphp
      @for($i = 0; $i < $remaining; $i++)
        <td style="background-color:transparent; width: {{ $colWidth }}px;">&nbsp;</td>
        @if($i < $remaining-1 && $gridGap > 0)
          <td class="gap-column" style="width: {{ $gridGap }}px;">&nbsp;</td>
        @endif
      @endfor
    </tr>
  @endforeach
</table>

<!--[if mso]>
</td></tr></table>
<![endif]-->
@endif
