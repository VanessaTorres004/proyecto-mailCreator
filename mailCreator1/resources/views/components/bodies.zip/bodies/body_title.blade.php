<!-- body_title.blade.php versión compatible con email -->
@php
  $title = $content['title'] ?? '';
  $maxWidth = 600;
@endphp

@if(!empty($title))
<table align="center" cellpadding="0" cellspacing="0" border="0" 
       width="100%" style="max-width:{{ $maxWidth }}px; margin:0 auto; border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
  <tr>
    <td align="left" style="padding:15px 20px; font-family:Arial, Helvetica, sans-serif;">
      <div style="font-size:24px; font-weight:bold; line-height:1.3; color:#333333; margin:0;">
        {!! $title !!}
      </div>
    </td>
  </tr>
</table>
@endif
