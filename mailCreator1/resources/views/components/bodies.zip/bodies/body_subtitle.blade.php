<!-- body_subtitle.blade.php-->
@php
  $subtitle = $content['subtitle'] ?? '';
  $maxWidth = 600;
@endphp

@if(!empty($subtitle))
<table align="center" cellpadding="0" cellspacing="0" border="0" 
       width="100%" style="max-width:{{ $maxWidth }}px; margin:0 auto; border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
  <tr>
    <td align="left" style="padding:10px 20px; font-family:Arial, Helvetica, sans-serif;">
      <div style="font-size:18px; font-weight:600; line-height:1.4; color:#555555; margin:0;">
        {!! $subtitle !!}
      </div>
    </td>
  </tr>
</table>
@endif
