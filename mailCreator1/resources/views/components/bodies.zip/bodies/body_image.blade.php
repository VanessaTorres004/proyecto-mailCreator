<!-- body_image.blade.php -->
@php
  $image = $content['image'] ?? '';
  $imageWidth = min($content['image_width'] ?? 200, 600); // Limit to 600px max
  $imageHeight = $content['image_height'] ?? null; // null mantiene proporción
  $imageAlign = $content['image_align'] ?? 'center';
  $imageBorderColor = $content['image_border_color'] ?? '#000000';
  $imageBorderWidth = $content['image_border_width'] ?? 0;
  $imageBorderRadius = $content['image_border_radius'] ?? 0;

  $alignMap = ['left' => 'left', 'center' => 'center', 'right' => 'right'];
  $alignment = $alignMap[$imageAlign] ?? 'center';
@endphp

<table align="{{ $alignment }}" cellpadding="0" cellspacing="0" border="0" width="100%">
  <tr>
    <td style="text-align:{{ $alignment }}; padding:0; margin:0;">

      @if(!empty($image))
        <!--[if mso]>
        <v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word"
          style="height:{{ $imageHeight ?? $imageWidth }}px; width:{{ $imageWidth }}px; v-text-anchor:middle;"
          arcsize="{{ $imageBorderRadius / $imageWidth }}"
          strokeweight="{{ $imageBorderWidth }}px"
          strokecolor="{{ $imageBorderColor }}"
          fill="true">
          <v:fill type="frame" src="{{ asset($image) }}" color="transparent" />
          <w:anchorlock/>
        </v:roundrect>
        <![endif]-->

        <!--[if !mso]><!-- -->
        <img src="{{ asset($image) }}"
             width="{{ $imageWidth }}"
             @if($imageHeight) height="{{ $imageHeight }}" @endif
             style="display:block; width:{{ $imageWidth }}px; @if($imageHeight) height:{{ $imageHeight }}px; @else height:auto; @endif; border:{{ $imageBorderWidth }}px solid {{ $imageBorderColor }}; border-radius:{{ $imageBorderRadius }}px; outline:none; text-decoration:none; -ms-interpolation-mode:bicubic; margin:0 auto;"
             alt="Imagen">
        <!--<![endif]-->
      @else
        <!-- Marcador de posición cuando no hay imagen -->
        <div style="display:inline-block; width:{{ $imageWidth }}px; height:{{ $imageHeight ?? $imageWidth }}px; border:{{ $imageBorderWidth }}px dashed {{ $imageBorderColor }}; border-radius:{{ $imageBorderRadius }}px; text-align:center; line-height:{{ $imageHeight ?? $imageWidth }}px; color:#888; font-size:14px; margin:0 auto;">
          Imagen
        </div>
      @endif

    </td>
  </tr>
</table>
